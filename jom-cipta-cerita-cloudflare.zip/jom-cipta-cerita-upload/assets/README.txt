Folder assets disediakan untuk gambar, audio atau bahan tambahan game.
HTML yang diberikan setakat ini tidak memerlukan fail tambahan dalam folder ini.
