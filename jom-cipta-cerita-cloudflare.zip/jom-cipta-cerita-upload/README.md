# Jom Cipta Cerita!

DLO Bahasa Melayu Tahun 6 – Menjaga Kebersihan Sekolah.

## Cara menerbitkan
Muat naik keseluruhan kandungan folder ini ke Cloudflare Pages menggunakan kaedah Direct Upload / Upload assets.

Fail utama laman web ialah `index.html`.
